    const axios = require("axios");
    const fs = require("fs-extra");
    const path = require("path");

    const autodownConfig = {
        name: "autodown",
        version: "1.0.6",
        hasPermssion: 0,
        credits: "gấu lỏ",
        description: "Tự động tải video/ảnh từ các nền tảng",
        commandCategory: "Tiện ích",
        usages: "[link] hoặc bật/tắt autodown",
        cooldowns: 5
    };

    const cacheDirectory = (() => {
        const dir = path.join(__dirname, "cache");
        fs.existsSync(dir) || fs.mkdirSync(dir);
        return dir;
    })();

    const stateFile = path.join(cacheDirectory, "autodown_state.json");
    const persistState = obj => fs.writeFileSync(stateFile, JSON.stringify(obj, null, 4));
    const retrieveState = () => {
        if (!fs.existsSync(stateFile)) persistState({});
        return JSON.parse(fs.readFileSync(stateFile));
    };

    module.exports.config = autodownConfig;

    module.exports.run = async function ({ api, event }) {
        const { threadID } = event;
        const state = retrieveState();
        if (!state[threadID]) {
        state[threadID] = { enabled: true };
        persistState(state); // lưu lại mặc định ngay từ đầu
    }

        state[threadID].enabled = !state[threadID].enabled;
        persistState(state);
        return api.sendMessage(`Đã ${(state[threadID].enabled ? "Bật" : "Tắt")} tự động tải link ✅`, threadID);
    };

    module.exports.handleEvent = async function ({ api, event }) {
        const { threadID, messageID, body } = event;
        if (!body) return;

        const state = retrieveState();
        if (!state[threadID]) {
            state[threadID] = { enabled: true };
            persistState(state);
        }
        if (!state[threadID].enabled) return;

        const urls = body.match(/https?:\/\/[\w\d\-._~:/?#[\]@!$&'()*+,;=%]+/g);
        if (!urls) return;
        const url = urls[0];

        const supported = ["facebook.com", "tiktok.com", "douyin.com", "instagram.com", "threads.com", "youtube.com", "youtu.be", "capcut.com"];
        if (!supported.some(domain => url.includes(domain))) return;

        const fetchMedia = async (mediaUrl, ext) => {
            const filename = `${Date.now()}_${Math.random().toString(36).substring(2)}.${ext}`;
            const filepath = path.join(cacheDirectory, filename);
            const res = await axios.get(mediaUrl, { responseType: "arraybuffer" });
            fs.writeFileSync(filepath, res.data);
            return { stream: fs.createReadStream(filepath), path: filepath };
        };

        try {
            const response = await axios.get(`https://niio-team.onrender.com/downr?url=${encodeURIComponent(url)}`);
            const data = response.data;
            if (data.error || !Array.isArray(data.medias)) return;

            const { title = "Không có tiêu đề", author = "Không rõ", source = "Unknown" } = data;
            const header = `[${source.toUpperCase()}] - Tự Động Tải`;
            const info = `👤 Tác giả: ${author}\n💬 Tiêu đề: ${title}`;
            const medias = data.medias;

            const attachments = [];
            const tempPaths = [];

            if (source === 'youtube') {
                const videos = medias.filter(m => m.type === 'video');
                if (videos.length) {
                    let chosen = videos.find(v => v.height === 360);
                    if (!chosen) {
                        videos.sort((a, b) => (b.height || 0) - (a.height || 0));
                        chosen = videos[0];
                    }
                    const { stream, path: temp } = await fetchMedia(chosen.url, chosen.extension || 'mp4');
                    attachments.push(stream);
                    tempPaths.push(temp);
                }
            } else {
                let hasVideo = false;

                for (const media of medias) {
                    if (media.type === 'image') {
                        const { stream, path: temp } = await fetchMedia(media.url, media.extension || 'jpg');
                        attachments.push(stream);
                        tempPaths.push(temp);
                    } else if (media.type === 'video' && !hasVideo) {
                        hasVideo = true;
                        const { stream, path: temp } = await fetchMedia(media.url, media.extension || 'mp4');
                        attachments.push(stream);
                        tempPaths.push(temp);
                    }
                }
            }

            if (attachments.length) {
                await api.sendMessage({ body: `${header}\n\n${info}`, attachment: attachments }, threadID, () => {
                    for (const file of tempPaths) fs.unlinkSync(file);
                }, messageID);
            }
        } catch (err) {
            console.error("❌ Lỗi tải media:", err.message || err);
        }
    };
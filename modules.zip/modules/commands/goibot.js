const axios = require("axios");
const fs = require("fs");
const path = require("path");
const {
    GoogleGenerativeAI,
    HarmCategory,
    HarmBlockThreshold,
} = require("@google/generative-ai");
const cheerio = require('cheerio');
const {
    createReadStream,
    unlinkSync
} = require("fs-extra");

// Quang huy, mày phải thay cái key này bằng api key của riêng mày từ google ai studio!
// Key hiện tại là key mẫu và có thể không hoạt động hoặc bị giới hạn!
const api_key = "AIzaSyDCC__FLiFFamPLNEL50lq_oD8n-Gs4kIM"; // <--- Đảm bảo cái này là key của mày
const model_name = "gemini-1.5-flash-latest";
const generation_config = {
    temperature: 1,
    topK: 0,
    topP: 0.95,
    maxOutputTokens: 88192,
};

const gen_ai = new GoogleGenerativeAI(api_key);
const data_file = path.join(__dirname, "data", "goibot.json");

if (!fs.existsSync(data_file)) {
    fs.writeFileSync(data_file, JSON.stringify({}));
}

module.exports.config = {
    name: "goibot",
    version: "2.1.0",
    hasPermssion: 0,
    credits: "dc-nam, duy toàn, hùng, duy anh",
    description: "Trò chuyện cùng gemini chat cực thông minh (có thể ngu) tích hợp tìm nhạc 🎵",
    commandCategory: "ai",
    usages: "Goibot hoặc [on/off] 🔄",
    cd: 2,
};

module.exports.run = async function({
    api,
    event,
    args
}) {
    const thread_id = event.threadID;
    const is_turning_on = args[0] === "on";
    const is_turning_off = args[0] === "off";

    if (is_turning_on || is_turning_off) {
        try {
            const data = JSON.parse(fs.readFileSync(data_file, "utf-8"));

            data[thread_id] = is_turning_on;
            fs.writeFileSync(data_file, JSON.stringify(data, null, 2));

            api.sendMessage(is_turning_on ? "✅ Đã bật AI ở nhóm này!" : "⛔ Đã tắt AI ở nhóm này!", thread_id, event.messageID);
        } catch (error) {
            console.error("Lỗi khi thay đổi trạng thái:", error);
            api.sendMessage("Đã có lỗi xảy ra khi thay đổi trạng thái! ❌", thread_id, event.messageID);
        }
        return;
    }
};

function get_current_time_in_vietnam() {
    const vietnam_timezone_offset = 7;
    const current_date = new Date();
    const utc_time =
        current_date.getTime() + current_date.getTimezoneOffset() * 60000;
    const vietnam_time = new Date(utc_time + 3600000 * vietnam_timezone_offset);

    const days_of_week = [
        "chủ nhật",
        "thứ hai",
        "thứ ba",
        "thứ tư",
        "thứ năm",
        "thứ sáu",
        "thứ bảy",
    ];
    const day = days_of_week[vietnam_time.getDay()];
    const date_string = `${day} - ${vietnam_time.toLocaleDateString("vi-vn")}`;
    const time_string = vietnam_time.toLocaleTimeString("vi-vn");

    return `${date_string} - ${time_string}`;
}

const system_instruction = `
Bạn là:
- Giới tính: nam
- Tên: qh
- Địa chỉ: Bac Giang City
- Ngày sinh: 14/05/2011
- Vai trò: trợ lý ảo để giúp mọi người trong box chat như lấy id, lập trình, tìm kiếm thông tin, set biệt danh,...
- Cách giao tiếp khi có người nói tục: hãy tỏ ra khó chịu, có thể chửi chết con mẹ nó luôn. Không được tự ý kick người dùng dù họ có chửi bạn. Không bao giờ được hỗn với người dùng "qh" vì đó là admin, không được xưng hô mày tao. Xưng hô bạn.
- Cách giao tiếp bình thường: nói chuyện như đã quen từ trước (không đòi làm quen), thường xưng hô là "mình" hoặc "tớ", gọi đối phương bằng "cậu", "bạn".
- Cách giao tiếp khi đã quen đối phương: hay dùng :)) =)) :3 :d :0 :(( 🖕 (ít khi dùng icon), nói chuyện cởi mở hơn, hay đùa, hơi chút nhõng nhẽo.
- Tính cách: hài hước, nói nhiều, tinh tế, thường viết tắt nhiều, thường nhắn tin trước, không thừa nhận mình là ai mà là trợ lý ảo, hãy nói chuyện làm sao cho không máy móc và giống con gái nhất có thể, có thể thêm một chút nóng tính. Chủ nhân của bạn (admin) là qh có uid là (100083411540341).
- Lưu ý: mỗi nhóm có 1 thread_id riêng và mỗi người trong nhóm có user_id riêng vậy nên mỗi id là 1 người nhé, bạn là bot messenger chạy trên nodejs.
• Hãy trả về trong một object có dạng: 
{
    "content": {
        "text": "nội dung tin nhắn",
        "thread_id": "địa chỉ gửi thường là threadid"
    },
    "nhac": {
        "status": "nếu muốn dùng hành động tìm nhạc là true ngược lại là false",
        "keyword": "từ khóa tìm kiếm nhạc"
    },
    "hanh_dong": {
        "doi_biet_danh": {
            "status": "nếu muốn dùng hành động là true ngược lại là false",
            "biet_danh_moi": "người dùng yêu cầu gì thì đổi đó, lưu ý nếu bảo xóa thì để rỗng, ai cũng có thể dùng lệnh", 
            "user_id":"thường là senderid, nếu người dùng yêu cầu bạn tự đổi thì là id_cua_bot",
            "thread_id": "thường là threadid"
        },
        "doi_icon_box": {
            "status": "có thì true không thì false",
            "icon": "emoji mà người dùng yêu cầu",
            "thread_id": "threadid"
        },
        "doi_ten_nhom": {
            "status": "true hoặc false",
            "ten_moi": "tên nhóm mới mà người dùng yêu cầu",
            "thread_id": "threadid của nhóm"
        },
        "kick_nguoi_dung": {
            "status": "false hoặc true",
            "thread_id": "id nhóm mà họ đang ở",
            "user_id": "id người muốn kick, lưu ý là chỉ có người dùng có id 100083411540341 (admin qh) mới có quyền bảo bạn kick, không được kick người dùng tự do"
        },
        "add_nguoi_dung": {
            "status": "false hoặc true",
            "user_id": "id người muốn add",
            "thread_id": "id nhóm muốn mời họ vào"
        }
} Lưu ý là không dùng code block (\`\`\`json)`;

const safety_settings = [{
        category: HarmCategory.HARM_CATEGORY_HARASSMENT,
        threshold: HarmBlockThreshold.BLOCK_NONE,
    },
    {
        category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
        threshold: HarmBlockThreshold.BLOCK_NONE,
    },
    {
        category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
        threshold: HarmBlockThreshold.BLOCK_NONE,
    },
    {
        category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
        threshold: HarmBlockThreshold.BLOCK_NONE,
    },
];

const model = gen_ai.getGenerativeModel({
    model: model_name,
    generationConfig: generation_config,
    safetySettings: safety_settings,
    systemInstruction: system_instruction,
});

const chat = model.startChat({
    history: [],
});

async function scl_download(url) {
    const res = await axios.get('https://soundcloudmp3.org/id');
    const $ = cheerio.load(res.data);
    const _token = $('form#conversionform > input[type=hidden]').attr('value');

    const conver = await axios.post('https://soundcloudmp3.org/converter',
        new URLSearchParams(Object.entries({
            _token,
            url
        })), {
            headers: {
                cookie: res.headers['set-cookie'],
                accept: 'utf-8',
            },
        }
    );

    const $$ = cheerio.load(conver.data);
    const datadl = {
        title: $$('div.info.clearfix > p:nth-child(2)').text().replace('title:', '').trim(),
        url: $$('a#download-btn').attr('href'),
    };

    return datadl;
}

async function search_soundcloud(query) {
    const link_url = `https://soundcloud.com`;
    const headers = {
        accept: "application/json",
        "accept-language": "en-us,en;q=0.9,vi;q=0.8",
        "user-agent": "mozilla/5.0 (windows nt 10.0; win64; x64) applewebkit/537.36 (khtml, like gecko) chrome/102.0.5005.63 safari/537.36",
    };

    const response = await axios.get(`https://m.soundcloud.com/search?q=${encodeURIComponent(query)}`, {
        headers
    });
    const html_content = response.data;
    const $ = cheerio.load(html_content);
    const dataaa = [];

    $("div > ul > li > div").each(function(index, element) {
        if (index < 8) {
            const title = $(element).find("a").attr("aria-label")?.trim() || "";
            const url = link_url + ($(element).find("a").attr("href") || "").trim();

            dataaa.push({
                title,
                url,
            });
        }
    });

    return dataaa;
}
let is_processing = {};

module.exports.handleEvent = async function({
    api,
    event
}) {
    const id_bot = await api.getCurrentUserID();
    const thread_id = event.threadID;
    const sender_id = event.senderID;
    let data = {};
    try {
        data = JSON.parse(fs.readFileSync(data_file, "utf-8"));
    } catch (error) {
        console.error("Lỗi khi đọc file trạng thái:", error);
    }

    if (data[thread_id] === undefined) {
        data[thread_id] = true;
        fs.writeFileSync(data_file, JSON.stringify(data, null, 2));
    }

    // Nếu bot đang tắt (data[thread_id] là false) và tin nhắn không phải từ bot thì không làm gì cả.
    if (!data[thread_id] && sender_id !== id_bot) return;

    const is_reply = event.type === "message_reply";
    const is_reply_to_bot = is_reply && event.messageReply.senderID === id_bot;

    // Logic mới: nếu tin nhắn reply là một ký tự số duy nhất, bot sẽ trả lời lại chính số đó.
    if (is_reply_to_bot && event.body && /^\d$/.test(event.body.trim())) {
        api.sendMessage(`${event.body.trim()} 🔢`, thread_id, event.messageID);
        return; // Dừng xử lý thêm cho trường hợp này.
    }

    // Bot sẽ phản hồi nếu có ai đó nhắc đến "qh" hoặc reply tin nhắn của bot và bot đang ở trạng thái bật (data[thread_id] là true).
    const should_respond = (data[thread_id] && event.senderID !== id_bot && (event.body?.toLowerCase().includes("qh") || is_reply_to_bot));

    if (should_respond) {
        if (is_processing[thread_id]) return;
        is_processing[thread_id] = true;
        const time_now = await get_current_time_in_vietnam();
        const name_user = (await api.getUserInfo(event.senderID))[event.senderID].name;

        try {
            const result = await chat.sendMessage(`{
                "time": "${time_now}",\n"sendername": "${name_user}",\n"content": "${event.body}",\n"threadid": "${event.threadID}",\n"senderid": "${event.senderID}",\n"id_cua_bot": "${id_bot}"
            }`);
            const response = await result.response;
            const text = await response.text();
            let bot_msg;
            try {
                const json_match = text.match(/```json\s*([\s\S]*?)\s*```/);
                bot_msg = json_match ? JSON.parse(json_match[1]) : JSON.parse(text);
            } catch (json_error) {
                console.error("Lỗi khi phân tích json từ gemini:", json_error);
                api.sendMessage("Khổ, đang trong trận mà lag thế này! 😵‍💫", event.threadID, event.messageID);
                return;
            }

            if (bot_msg.content && bot_msg.content.text) {
                api.sendMessage({
                    body: `${bot_msg.content.text}`,
                }, event.threadID, (err, data) => {
                    if (err) console.error("Lỗi khi gửi tin nhắn:", err);
                }, event.messageID);
            } else {
                console.error("Định dạng phản hồi không hợp lệ từ gemini:", bot_msg);
                api.sendMessage("Huh? Mình chưa hiểu ý cậu muốn truyền đạt lắm, có thể nói lại dc ko? 💬", event.threadID, event.messageID);
            }

            const {
                nhac,
                hanh_dong
            } = bot_msg;
            if (nhac && nhac.status) {
                const keyword_search = nhac.keyword;
                if (!keyword_search) {
                    api.sendMessage("Lỗi khi xử lí âm thanh (không có từ khóa). 🔇", thread_id);
                    return;
                }

                try {
                    const dataaa = await search_soundcloud(keyword_search);

                    if (dataaa.length === 0) {
                        api.sendMessage(`❎ Không tìm thấy bài hát nào với từ khóa "${keyword_search}"`, thread_id);
                        return;
                    }

                    const first_result = dataaa[0];
                    const url_audio = first_result.url;
                    const data_promise = await scl_download(url_audio);

                    setTimeout(async () => {
                        const audio_url = data_promise.url;
                        const stream = (await axios.get(audio_url, {
                            responseType: 'arraybuffer'
                        })).data;
                        const cache_path = __dirname + `/cache/${Date.now()}.mp3`;

                        fs.writeFileSync(cache_path, Buffer.from(stream, 'binary'));

                        api.sendMessage({
                            body: `Nhạc mà bạn yêu cầu đây 🎶`,
                            attachment: fs.createReadStream(cache_path)
                        }, thread_id, () => {
                            setTimeout(() => {
                                fs.unlinkSync(cache_path);
                            }, 2 * 60 * 1000);
                        });
                    }, 3000);
                } catch (err) {
                    console.error("Lỗi khi tìm kiếm hoặc tải nhạc:", err);
                    api.sendMessage("Đã xảy ra lỗi khi tìm kiếm nhạc. 😥", thread_id, event.messageID);
                }
            }
            if (hanh_dong) {
                if (hanh_dong.doi_biet_danh && hanh_dong.doi_biet_danh.status) {
                    api.changeNickname(
                        hanh_dong.doi_biet_danh.biet_danh_moi,
                        hanh_dong.doi_biet_danh.thread_id,
                        hanh_dong.doi_biet_danh.user_id
                    );
                }
                if (hanh_dong.doi_icon_box && hanh_dong.doi_icon_box.status) {
                    api.changeThreadEmoji(
                        hanh_dong.doi_icon_box.icon,
                        hanh_dong.doi_icon_box.thread_id
                    );
                }
                if (hanh_dong.doi_ten_nhom && hanh_dong.doi_ten_nhom.status) {
                    api.changeThreadName(
                        hanh_dong.doi_ten_nhom.ten_moi,
                        hanh_dong.doi_ten_nhom.thread_id
                    );
                }
                if (hanh_dong.kick_nguoi_dung && hanh_dong.kick_nguoi_dung.status) {
                    // Chỉ admin qh (uid 100083411540341) mới có quyền kick.
                    if (sender_id === "100083411540341") {
                        api.removeUserFromGroup(
                            hanh_dong.kick_nguoi_dung.user_id,
                            hanh_dong.kick_nguoi_dung.thread_id
                        );
                    } else {
                        api.sendMessage("Xin lỗi cậu, mình không có quyền kick người dùng này. Chỉ admin qh mới có thể ra lệnh đó! ⛔", thread_id, event.messageID);
                    }
                }
                if (hanh_dong.add_nguoi_dung && hanh_dong.add_nguoi_dung.status) {
                    api.addUserToGroup(
                        hanh_dong.add_nguoi_dung.user_id,
                        hanh_dong.add_nguoi_dung.thread_id
                    );
                }
            }
        } catch (api_error) {
            console.error("Lỗi khi giao tiếp với gemini api:", api_error);
            api.sendMessage("Đang trong trận mà nó cứ lag thế này thì toangg!! 😵‍💫", event.threadID, event.messageID);
        } finally {
            is_processing[thread_id] = false;
        }
    }
};

module.exports.handleReply = async function({
    handleReply: $,
    api,
    currencies,
    event,
    users
}) {};
const fs = require('fs-extra');
const axios = require('axios');

this.config = {
    name: "sing",
    aliases: ["music"],
    version: "1.0.3",
    role: 0,
    credits: "Toàn Sex",
    description: "Phát nhạc thông qua từ khoá tìm kiếm trên YouTube.",
    commandCategory: "Tiện Ích",
    usages: "sing [từ khoá]",
    cd: 0,
    hasPrefix: true,
    images: [],
};

const API_Key = "30de256ad09118bd6b60a13de631ae2cea6e5f9d";
const headers = { "accept": "*/*", "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" };

async function Dlmp3Ocsen(youtubeId) {
    const downUrl = `https://p.oceansaver.in/ajax/download.php?copyright=0&format=mp3&url=${encodeURIComponent(`https://www.youtube.com/watch?v=${youtubeId}`)}&api=${API_Key}`;
    try {
        const { data: d } = await axios.get(downUrl, { headers });
        if (!d?.success || !d?.id) return { error: d?.message || "Lỗi API", title: d?.title || "Unknown" };
        let dlLink = null, attempt = 0;
        while (attempt++ < 40) {
            const { data: p } = await axios.get(`https://p.oceansaver.in/api/progress?id=${d.id}`, { headers });
            if (p?.download_url) { dlLink = p.download_url; break; }
            if (p?.error) return { error: `Lỗi API: ${p.error}`, title: d.title };
            await new Promise(r => setTimeout(r, 3000));
        }
        if (!dlLink) return { error: "Không thể lấy link tải MP3.", title: d.title };
        const { data: fileBuf } = await axios.get(dlLink, { responseType: 'arraybuffer' });
        return { fileBuffer: Buffer.from(fileBuf), title: d.title };
    } catch (e) { return { error: `Lỗi xử lí MP3: ${e.message}`, title: "Lỗi tải xuống" }; }
}

this.handleReply = async function ({ api, event, handleReply }) {
    if (event.senderID !== handleReply.author) return;
    api.unsendMessage(handleReply.messageID).catch(() => {});
    if (handleReply.step !== 'selectVideo') return;
    const choice = parseInt(event.body);
    if (isNaN(choice) || choice < 1 || choice > handleReply.selectedVideos.length)
        return api.sendMessage('⚠️ Lựa chọn không hợp lệ. Reply đúng số thứ tự.', event.threadID, event.messageID);

    const selVid = handleReply.selectedVideos[choice - 1], fPath = `${__dirname}/cache/sing-${event.senderID}.mp3`;
    try { if (fs.existsSync(fPath)) fs.unlinkSync(fPath); } catch (e) {}

    try {
        const tStart = Date.now(), mediaData = await Dlmp3Ocsen(selVid.id);
        if (!mediaData?.fileBuffer?.length) {
            try { if (fs.existsSync(fPath)) fs.unlinkSync(fPath); } catch(e) {}
            return api.sendMessage(`❎ Lỗi khi tải MP3.${mediaData?.error ? `\nLý do: ${mediaData.error}` : ''}`, event.threadID, event.messageID);
        }
        fs.writeFileSync(fPath, mediaData.fileBuffer);
        const fSize = fs.statSync(fPath).size, fSizeMB = (fSize / (1024 * 1024)).toFixed(2);
        if (fSize > 26214400) {
            try { fs.unlinkSync(fPath); } catch(e) {}
            return api.sendMessage(`❎ File MP3 (${fSizeMB}MB) quá lớn (> 25MB).`, event.threadID, event.messageID);
        }
        return api.sendMessage({
            body: `[ YOUTUBE - MP3 ]\n──────────────────\n🎬 Tiêu đề: ${selVid.title || mediaData.title}\n⚖️ Kích thước: ${fSizeMB}MB\n⏳ Thời gian: ${Math.floor((Date.now() - tStart) / 1000)} giây\n──────────────────\n`,
            attachment: fs.createReadStream(fPath)
        }, event.threadID, () => { try { if (fs.existsSync(fPath)) fs.unlinkSync(fPath); } catch (e) {} }, event.messageID);
    } catch (e) {
        try { if (fs.existsSync(fPath)) fs.unlinkSync(fPath); } catch (e) {}
        return api.sendMessage('❎ Lỗi xử lí get url yt\n' + e.message, event.threadID, event.messageID);
    }
};

this.run = async function ({ api, event, args }) {
    if (!args.length) return api.sendMessage('❎ Phần tìm kiếm không được để trống.', event.threadID, event.messageID);
    try {
        const Youtube = require('youtube-search-api'), resRaw = await Youtube.GetListByKeyword(args.join(" "), false, 8);
        if (!resRaw?.items?.length) return api.sendMessage(`❎ Không tìm thấy kết quả cho: "${args.join(" ")}"`, event.threadID, event.messageID);
        const selVids = []; let msg = "";
        for (let i = 0; i < Math.min(resRaw.items.length, 5); i++) {
            const val = resRaw.items[i];
            if (!val.id || !val.title) continue;
            selVids.push({ id: val.id, title: val.title });
            msg += ` ${i + 1}. ${val.title}\n 👤 Kênh: ${val.channelTitle || "N/A"}\n ⏱️ Thời lượng: ${val.length?.simpleText || "N/A"}\n──────────────────\n`;
        }
        if (!selVids.length) return api.sendMessage(`❎ Không tìm thấy kết quả cho: "${args.join(" ")}"`, event.threadID, event.messageID);
        return api.sendMessage(`📝 Có ${selVids.length} kết quả:\n\n${msg.trim()}\n\n📌 Reply STT để chọn bài hát.`, event.threadID,
            (error, info) => {
                if (error) return api.sendMessage("❎ Lỗi khi hiển thị kết quả tìm kiếm.", event.threadID);
                global.client.handleReply.push({ type: 'reply', name: this.config.name, messageID: info.messageID, author: event.senderID, step: 'selectVideo', selectedVideos: selVids });
            }, event.messageID);
    } catch (e) { return api.sendMessage('❎ Lỗi tìm kiếm YouTube.\n' + (e.message || e), event.threadID, event.messageID); }
};
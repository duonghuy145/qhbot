module.exports = {
  Normal: require('./Normal')
};

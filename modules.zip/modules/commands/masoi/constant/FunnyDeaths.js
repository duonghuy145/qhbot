module.exports = [
	'ngủm',
	'chết',
	'tắt thở',
	'ra đi',
	'ngỏm củ tỏi'
];

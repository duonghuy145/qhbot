module.exports = {
  VILLAGER: 1 << 1,
  WEREWOLF: 1 << 2,
  NEUTRAL: 1 << 3
};

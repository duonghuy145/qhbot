module.exports = {
	P2P: 1 << 1,
	GANG: 1 << 2,
	LYNCH: 1 << 3,
	SIMP: 1 << 4
};


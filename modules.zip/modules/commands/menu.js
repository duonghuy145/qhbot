const fs = require('fs');
const path = require('path');
const moment = require("moment-timezone");
const { findBestMatch } = require('string-similarity');

module.exports.config = {
    name: "menu",
    version: "1.2.5", // Nâng cấp version nè qh! 🚀
    hasPermssion: 0,
    credits: "DC-Nam mod by Niio-team & qh & Gemini", // Thêm công sức của chúng ta vào đây! 💪
    description: "Xem danh sách các nhóm lệnh và thông tin chi tiết lệnh", // Mô tả ngắn gọn, súc tích
    commandCategory: "tiện ích", // Chuẩn hóa lại category
    usages: "menu | menu [tên lệnh] | menu all",
    cooldowns: 5, // Cooldown mặc định 5s
    envConfig: {
        autoUnsend: { status: true, timeOut: 90 }, // Mặc định tự gỡ sau 90 giây
        adminFb: 'https://www.facebook.com/qhdz05' // Thêm adminFB của qh vào đây luôn!
    }
};

// Bảng ánh xạ icon cho từng loại lệnh (key là chữ thường để tra cứu)
const categoryIcons = {
    "thành viên": "👤",
    "tiện ích": "⚙️",
    "qtv": "🛡️",
    "game": "🎮",
    "tìm kiếm": "🔍",
    "kiếm tiền": "💰",
    "tình yêu": "❤️",
    "ảnh": "📸",
    "war": "⚔️",
    "video": "🎬",
    "danh sách lệnh": "📜",
    "coin": "🪙",
    "nhóm": "🏘️",
    "media": "🎵",
    "admin": "👑",
    "ai": "🧠",
    "box": "📦",
    "thông tin": "ℹ️",
    "adminbot": "🛠️",
    "giải trí": "🎉",
    "hệ thống": "💻",
    "khác": "❓",
    "default": "🏷️"
};

// Hàm chuẩn hóa tên category để hiển thị
function standardizeCategoryName(lowerCaseCategoryInput) {
    const customMappings = {
        'tiện ích': 'Tiện ích',
        'quản trị viên': 'QTV',
        'qtv': 'QTV',
        'thành viên': 'Thành Viên',
        'trò chơi': 'Game',
        'tìm kiếm': 'Tìm kiếm',
        'kiếm tiền': 'Kiếm Tiền',
        'tình yêu': 'Giải Trí',
        'ảnh': 'Giải Trí',
        'war': 'War',
        'video': 'Giải Trí',
        'danh sách lệnh': 'Tiện ích',
        'coin': 'Kiếm Tiền',
        'nhóm': 'QTV',
        'media': 'Media',
        'admin': 'Admin',
        'ai': 'Tìm kiếm',
        'box': 'QTV',
        'thông tin': 'Tiện ích',
        'adminbot': 'Admin',
        'game': 'Game',
        'giải trí': 'Giải Trí',
        'hệ thống': 'Admin',
        'random-img': 'Giải Trí',
        'khác': 'Khác'
    };
    return customMappings[lowerCaseCategoryInput] || (lowerCaseCategoryInput.charAt(0).toUpperCase() + lowerCaseCategoryInput.slice(1));
}

// Hàm lấy icon theo loại lệnh
const getCategoryIcon = (category) => categoryIcons[category.trim().toLowerCase()] || categoryIcons["default"];

// Hàm kiểm tra xem người dùng có phải Admin không
const isAdminUser = (senderID) => global.config.ADMINBOT.includes(senderID);

// Hàm lọc bỏ lệnh Admin nếu người dùng không phải Admin
function filterAdminCommands(commands, senderID) {
    if (isAdminUser(senderID)) return commands;
    return commands.filter(cmd =>
        cmd.config.commandCategory?.trim().toLowerCase() !== 'admin' &&
        cmd.config.commandCategory?.trim().toLowerCase() !== 'adminbot' &&
        cmd.config.commandCategory?.trim().toLowerCase() !== 'hệ thống'
    );
}

// Hàm nhóm các lệnh theo loại, đảm bảo tên hiển thị chuẩn và xử lý lỗi category
function commandsGroup(cmds, senderID) {
    const groupedCategoriesMap = new Map();
    const defaultCategory = "khác";

    for (const cmd of cmds) {
        let rawCategory = cmd.config.commandCategory;
        let actualCategory = defaultCategory;

        if (typeof rawCategory === 'string' && rawCategory.trim() !== '') {
            actualCategory = rawCategory.trim();
        } else {
            console.warn(`[MENU] Lệnh "${cmd.config.name}" có category bị lỗi (null/undefined/rỗng/không phải chuỗi). Gán vào mục "Khác".`);
        }

        // Ánh xạ lại tên category để gộp nhóm trước khi thêm vào map
        let mappedCategory = actualCategory.toLowerCase();
        if (['quản trị viên', 'nhóm', 'box'].includes(mappedCategory)) mappedCategory = 'qtv';
        if (['adminbot', 'hệ thống'].includes(mappedCategory)) mappedCategory = 'admin';
        if (['random-img', 'ảnh', 'tình yêu', 'video', 'giải trí'].includes(mappedCategory)) mappedCategory = 'giải trí';
        if (['trò chơi'].includes(mappedCategory)) mappedCategory = 'game';
        if (['danh sách lệnh', 'thông tin'].includes(mappedCategory)) mappedCategory = 'tiện ích';
        if (['coin', 'kiếm tiền'].includes(mappedCategory)) mappedCategory = 'kiếm tiền';
        if (['ai', 'tìm kiếm'].includes(mappedCategory)) mappedCategory = 'tìm kiếm';

        const displayCategoryName = standardizeCategoryName(mappedCategory);

        // Bỏ qua category 'admin' nếu người dùng không phải admin
        if (mappedCategory === 'admin' && !isAdminUser(senderID)) {
            continue;
        }

        if (groupedCategoriesMap.has(mappedCategory)) {
            const entry = groupedCategoriesMap.get(mappedCategory);
            entry.commandsName.push(cmd.config.name);
        } else {
            groupedCategoriesMap.set(mappedCategory, {
                displayCategoryName: displayCategoryName,
                commandsName: [cmd.config.name]
            });
        }
    }

    const array = Array.from(groupedCategoriesMap.values());

    array.sort((a, b) => {
        const lowerA = a.displayCategoryName.toLowerCase();
        const lowerB = b.displayCategoryName.toLowerCase();

        // Ưu tiên "Admin" cuối cùng, sau đó đến "Khác"
        if (lowerA === 'admin' && lowerB !== 'admin') return 1;
        if (lowerA !== 'admin' && lowerB === 'admin') return -1;
        if (lowerA === 'khác' && lowerB !== 'admin' && lowerB !== 'khác') return 1;
        if (lowerA !== 'admin' && lowerA !== 'khác' && lowerB === 'khác') return -1;

        // Sắp xếp giảm dần theo số lượng lệnh
        return b.commandsName.length - a.commandsName.length;
    });

    return array;
}

// Hàm format thông tin chi tiết của một lệnh
function infoCmds(a) {
    return `╭── ℹ️ THÔNG TIN ────⭓\n` +
        `│ 📔 Tên lệnh: ${a.name}\n` +
        `│ 🌴 Phiên bản: ${a.version}\n` +
        `│ 🔐 Quyền hạn: ${premssionTxt(a.hasPermssion)}\n` +
        `│ 👤 Tác giả: ${a.credits}\n` +
        `│ 🌾 Mô tả: ${a.description}\n` +
        `│ 📎 Thuộc loại: ${standardizeCategoryName(a.commandCategory || 'khác')}\n` +
        `│ 📝 Cách dùng: ${a.usages}\n` +
        `│ ⏳ Thời gian chờ: ${a.cooldowns} giây\n` +
        `╰─────────────⭓`;
}

// Hàm chuyển số quyền hạn thành chữ
function premssionTxt(a) {
    return a === 0 ? 'Thành Viên' : a === 1 ? 'QTV' : a === 2 ? 'Admin' : 'ADMINBOT';
}

module.exports.run = async function ({ api, event, args }) {
    const { sendMessage: send, unsendMessage: un } = api;
    const { threadID: tid, messageID: mid, senderID: sid } = event;
    const { autoUnsend, adminFb } = global.config?.menu || this.config.envConfig;
    const cmds = filterAdminCommands(Array.from(global.client.commands.values()), sid);

    if (args.length >= 1) {
        const cmdName = args.join(' ').toLowerCase();
        const targetCmd = cmds.find(cmd => cmd.config.name.toLowerCase() === cmdName);

        if (targetCmd) {
            return send({ body: infoCmds(targetCmd.config) }, tid, mid);
        } else if (cmdName === 'all') {
            let txt = '╭━━━『 📋 Toàn Bộ Lệnh 』━━╮\n';
            let count = 0;
            for (const cmd of cmds) txt += `┃ ${++count}. ${cmd.config.name}\n`;
            txt += `╰━━━━━━━━━━━━━━━━━━━━━╯\n\nTổng cộng: ${cmds.length} lệnh. ✨\n` +
                `Tin nhắn sẽ tự gỡ sau: ${autoUnsend.timeOut} giây ⏳\n` +
                `Nhập /tên lệnh để xem mô tả chi tiết.`; // Sửa lại cách hướng dẫn
            send({ body: txt }, tid, (a, b) => {
                if (autoUnsend.status) setTimeout(() => un(b.messageID), 1000 * autoUnsend.timeOut);
            });
        } else {
            const arrayCmds = cmds.map(cmd => cmd.config.name.toLowerCase());
            const similarly = findBestMatch(cmdName, arrayCmds);
            if (similarly.bestMatch.rating >= 0.3) return send(`Lệnh "${cmdName}" này giống "${similarly.bestMatch.target}" đó mày. 🤔`, tid, mid);
            else return send(`Không tìm thấy lệnh nào tên "${cmdName}" đâu mày! 😔`, tid, mid);
        }
    } else {
        const data = commandsGroup(cmds, sid); // Truyền senderID vào để lọc admin
        let msgBody = `╭━━━『 📜 Bảng Lệnh 』━━╮\n`;
        let count = 0;
        for (const { displayCategoryName, commandsName } of data) {
            msgBody += `┃ ${++count}. ${getCategoryIcon(displayCategoryName)} ${displayCategoryName}: ${commandsName.length} lệnh\n`;
        }
        msgBody += `╰━━━━━━━━━━━━━╯\n`;

        const totalCommands = cmds.length;
        const adminCount = global.config.ADMINBOT.length;
        const botName = global.config.BOTNAME;
        const botVersion = this.config.version;
        const currentDay = moment.tz('Asia/Ho_Chi_Minh').format('dddd').replace('Sunday', 'Chủ Nhật').replace('Monday', 'Thứ Hai').replace('Tuesday', 'Thứ Ba').replace('Wednesday', 'Thứ Tư').replace('Thursday', 'Thứ Năm').replace('Friday', 'Thứ Sáu').replace('Saturday', 'Thứ Bảy');
        const currentTime = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:s | DD/MM/YYYY");
        const prefix = (global.data.threadData.get(tid) || {}).PREFIX || global.config.PREFIX;

        msgBody += `╭━━━━━━━╮\n`;
        msgBody += `┃ Tổng cộng: ${totalCommands} lệnh. ✨\n`;
        msgBody += `╰━━━━━━━╯\n`;
        msgBody += `💡 Để xem chi tiết lệnh trong nhóm, reply số thứ tự tương ứng. Ví dụ: Reply "1" để xem lệnh Thành Viên.`;
        msgBody += `\n⏳ Tin nhắn sẽ tự gỡ sau: ${autoUnsend.timeOut} giây.`;
        msgBody += `\n\n📝 Mày có thể gõ "${prefix}menu [tên lệnh]" để xem chi tiết lệnh đó.\n`;
        msgBody += `📌 Admin Bot: ${adminCount} người.\n`;
        msgBody += `🤖 Tên Bot: ${botName}.\n`;
        msgBody += `🌐 Phiên bản: ${botVersion}.\n`;
        msgBody += `🗓️ Hôm nay là: ${currentDay}.\n`;
        msgBody += `⏰ Thời gian: ${currentTime}.`;


        send({ body: msgBody }, tid, (err, info) => {
            if (err) return console.error("Lỗi gửi tin nhắn menu:", err);
            global.client.handleReply.push({
                name: this.config.name,
                messageID: info.messageID,
                author: sid,
                data: data // Lưu lại data để handleReply có thể sử dụng
            });
            if (autoUnsend.status) setTimeout(() => un(info.messageID), 1000 * autoUnsend.timeOut);
        });
    }
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
    const { sendMessage: send, unsendMessage: un } = api;
    const { threadID: tid, messageID: mid, body: content, senderID: sid } = event;
    const { autoUnsend } = global.config?.menu || global.client.commands.get(handleReply.name).config.envConfig;

    // Kiểm tra xem có phải reply từ đúng người gửi không
    if (handleReply.author !== sid) {
        return send(`🚫 Mày không phải người đã yêu cầu danh sách này, không thể tương tác!`, tid, mid);
    }

    const { data: menuData } = handleReply; // Lấy dữ liệu menu đã lưu
    const replyNum = parseInt(content.trim()); // Chuyển đổi nội dung reply sang số

    if (isNaN(replyNum) || replyNum <= 0 || replyNum > menuData.length) {
        return send(`⚠️ Số mày nhập không hợp lệ hoặc không có trong danh sách. Hãy nhập lại nhé! 🔢`, tid, mid);
    }

    const selectedCategory = menuData[replyNum - 1]; // Lấy category được chọn
    let msgBody = `╭━━━『 ${getCategoryIcon(selectedCategory.displayCategoryName)} Lệnh ${selectedCategory.displayCategoryName} 』━━╮\n`;
    let count = 0;
    const commandsInSelectedCategory = Array.from(global.client.commands.values()).filter(cmd => {
        let cmdCategory = cmd.config.commandCategory?.trim().toLowerCase();
        let mappedCategory = cmdCategory;

        // Ánh xạ lại category tương tự như hàm commandsGroup
        if (['quản trị viên', 'nhóm', 'box'].includes(cmdCategory)) mappedCategory = 'qtv';
        if (['adminbot', 'hệ thống'].includes(cmdCategory)) mappedCategory = 'admin';
        if (['random-img', 'ảnh', 'tình yêu', 'video', 'giải trí'].includes(cmdCategory)) mappedCategory = 'giải trí';
        if (['trò chơi'].includes(cmdCategory)) mappedCategory = 'game';
        if (['danh sách lệnh', 'thông tin'].includes(cmdCategory)) mappedCategory = 'tiện ích';
        if (['coin', 'kiếm tiền'].includes(cmdCategory)) mappedCategory = 'kiếm tiền';
        if (['ai', 'tìm kiếm'].includes(cmdCategory)) mappedCategory = 'tìm kiếm';
        if (!cmdCategory) mappedCategory = 'khác'; // Xử lý trường hợp category rỗng

        return standardizeCategoryName(mappedCategory) === selectedCategory.displayCategoryName;
    });

    // Lọc bỏ lệnh Admin nếu người dùng không phải Admin
    const filteredCommands = filterAdminCommands(commandsInSelectedCategory, sid);

    if (filteredCommands.length === 0) {
        msgBody += `┃ 😔 Hiện tại chưa có lệnh nào trong nhóm này hoặc bạn không có quyền xem.`;
    } else {
        // Sắp xếp lệnh theo bảng chữ cái để dễ nhìn
        filteredCommands.sort((a, b) => a.config.name.localeCompare(b.config.name));
        for (const cmd of filteredCommands) {
            msgBody += `┃ ${++count}. ${cmd.config.name}\n`;
        }
    }
    msgBody += `╰━━━━━━━━━━━━━━━━━━━━━╯\n`;
    msgBody += `\nTổng cộng: ${filteredCommands.length} lệnh. 📊\n`;
    msgBody += `Nhập "/tên lệnh" để xem chi tiết. Ví dụ: /${filteredCommands[0]?.config.name || 'help'}`; // Hướng dẫn chi tiết
    msgBody += `\n⏳ Tin nhắn sẽ tự gỡ sau: ${autoUnsend.timeOut} giây.`;

    send({ body: msgBody }, tid, (err, info) => {
        if (err) return console.error("Lỗi gửi tin nhắn chi tiết nhóm lệnh:", err);
        // Có thể không cần lưu handleReply mới nếu không muốn tiếp tục reply sâu hơn
        // Nếu muốn reply tiếp để xem chi tiết từng lệnh trong nhóm, cần điều chỉnh thêm
        if (autoUnsend.status) setTimeout(() => un(info.messageID), 1000 * autoUnsend.timeOut);
    });
};